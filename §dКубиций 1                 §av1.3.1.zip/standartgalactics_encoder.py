print("  ╔══════════════════════════╗\n  ║    ┛Kostya Pictures┗     ║\n  ║Standart Galactics Encoder║\n  ╚══════════════════════════╝")
while True:
    print("Введите сообщение:")
    main=input()
    res=""
    ind=0
    for ind in range(len(main)):
        if main[ind]=="a": #оно начинается с \u99AA
            res+="\u99aa"
        elif main[ind]=="b":
            res+="\u99ab"
        elif main[ind]=="c":
            res+="\u99ac"
        elif main[ind]=="d":
            res+="\u99ad"
        elif main[ind]=="e":
            res+="\u99ae"
        elif main[ind]=="f":
            res+="\u99af"
        elif main[ind]=="g":
            res+="\u99ba"
        elif main[ind]=="h":
            res+="\u99bb"
        elif main[ind]=="i":
            res+="\u99bc"
        elif main[ind]=="j":
            res+="\u99bd"
        elif main[ind]=="k":
            res+="\u99be"
        elif main[ind]=="l":
            res+="\u99bf"
        elif main[ind]=="m":
            res+="\u99ca"
        elif main[ind]=="n":
            res+="\u99cb"
        elif main[ind]=="o":
            res+="\u99cc"
        elif main[ind]=="p":
            res+="\u99cd"
        elif main[ind]=="q":
            res+="\u99ce"
        elif main[ind]=="r":
            res+="\u99cf"
        elif main[ind]=="s":
            res+="\u99da"
        elif main[ind]=="t":
            res+="\u99db"
        elif main[ind]=="u":
            res+="\u99dc"
        elif main[ind]=="v":
            res+="\u99dd"
        elif main[ind]=="w":
            res+="\u99de"
        elif main[ind]=="x":
            res+="\u99df"
        elif main[ind]=="y":
            res+="\u99ea"
        elif main[ind]=="z":
            res+="\u99eb"
        else:
            res+=main[ind]
    print('результат (он должен быть либо квадратным с вопросиками, либо китайский):')
    print(res)